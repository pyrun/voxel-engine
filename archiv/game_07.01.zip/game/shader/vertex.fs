#version 400

layout( location = 0 ) out vec4 fragColor;

void main() {

    fragColor = vec4 ( 0.1, 0.1, 0.1, 1);
}
