#version 400

uniform sampler2D sampler;

in vec4 texcoord;

layout( location = 0 ) out vec4 fragColor;

void main() {

    fragColor = vec4( 1, 1, 1, 1);
}
